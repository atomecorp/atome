# frozen_string_literal: true

# For now markup can only be specified at creation time, it will be possible later
the_one = text({ data: :hello, markup: :h1 })
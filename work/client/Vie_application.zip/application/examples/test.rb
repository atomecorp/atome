puts 'hello'
puts Universe.particle_list
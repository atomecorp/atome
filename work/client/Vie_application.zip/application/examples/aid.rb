# frozen_string_literal: true


# aid is used to provide an unique and persistent id for any atome
b=box({ left: 12, id: :the_first_box })

puts " atome aid is : #{ b.aid}"

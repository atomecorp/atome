# #  frozen_string_literal: true
b = box

wait 2 do
  b.color(:red)
end
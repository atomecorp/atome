#  frozen_string_literal: true

# see import for drag and drop import
b = box({ drag: true })
b.import(true) do  |content|
  puts "add code here, content:  #{content}"
end










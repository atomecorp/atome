# frozen_string_literal: true

box({id: :my_box})
console(true)
# frozen_string_literal: true

puts "atomes : #{Universe.atomes}"
puts "user_atomes : #{Universe.user_atomes}"
puts "particle_list : #{Universe.particle_list}"
puts "users : #{Universe.users}"
puts "current_machine : #{Universe.current_machine}"
puts "internet connected : #{Universe.internet}"
# frozen_string_literal: true
b = box

b.style({ left: 33, width: 44, rotate: 23, color: :yellowgreen, blur: 44 })
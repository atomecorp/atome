# frozen_string_literal: true

text online?
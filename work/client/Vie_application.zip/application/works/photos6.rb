

c=circle({left: 333})
c.touch(true) do
  A.terminal('cd ../server;ruby capture.rb ../src/medias/images/photos/ ritounou')
end
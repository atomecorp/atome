# frozen_string_literal: true

# we check if the atome or the particle we want to create has already been defined in atome

new ({ atome: :image })

new ({ particle: :left })

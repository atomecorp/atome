# frozen_string_literal: true


class Atome
  def initialize(params = {}) end
end
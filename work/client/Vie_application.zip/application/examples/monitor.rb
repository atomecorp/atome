# frozen_string_literal: true
puts 'deprecated use clone monitoring'
# b = box({ id: :the_box })
# c = circle({ top: 3, id: :the_cirle })
# A.monitor({ atomes: [:the_box, :the_cirle], particles: [:left] }) do |atome, particle, value|
#   puts "changes : #{atome.id}, #{particle}, #{value}"
# end
#
# wait 2 do
#   b.left(3)
#   wait 2 do
#     c.left(444)
#   end
# end

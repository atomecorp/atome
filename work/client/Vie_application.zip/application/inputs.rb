# frozen_string_literal: true


A.input({ width: 166, back: :white, text: :black, default: 'type here',trigger: :up, }) do |val|
  puts "value : #{val}"
end




# frozen_string_literal: true


text("a whole new way to use atome :\n
 create a ruby file, ex : index.rb then type atome sparkle index\n
it will create an app and run it immediately")
#  frozen_string_literal: true

image(:red_planet)

image({path: 'medias/images/logos/atome.svg', width: 33})
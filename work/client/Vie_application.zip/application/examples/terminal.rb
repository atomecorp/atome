# frozen_string_literal: true
A.terminal('pwd') do |data|
  text "terminal response  :\n #{data}"
end
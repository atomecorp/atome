# frozen_string_literal: true

button = box({smooth: 6,left: 55,top: 160, color:{red: 0.3, green: 0.3, blue: 0.3},id: :my_box})
button.shadow({
                id: :s1,
                left: 3, top: 3, blur: 9,
                invert: true,
                red: 0, green: 0, blue: 0, alpha: 0.7
              })
button.touch(true) do
  button.controller(:hello)
end
slider=box({ width: 333, height: 25, top: 45, left: 55, smooth: 9,  color:{red: 0.3, green: 0.3, blue: 0.3}})
slider.shadow({
                id: :s2,
                left: 3, top: 3, blur: 9,
                invert: true,
                red: 0, green: 0, blue: 0, alpha: 0.7
              })
cursor= slider.circle({width: 30, height: 30, left: 2, top: 1, color:{red: 0.3, green: 0.3, blue: 0.3}})

cursor.left(0)
cursor.top(0)
cursor.shadow({
                id: :s4,
                left: 1, top: 1, blur: 3,
                option: :natural,
                red: 0, green: 0, blue: 0, alpha: 0.6
              })
label=text({data: 0, top: 69, left: 69, component: { size: 12 }, color: :gray})
cursor.drag({ restrict: {max:{ left: 309, top: 0}} }) do |event|
  # puts cursor.left
  value = cursor.left/309*100
  label.data(value)
  puts value
  # cursor.controller({ action: :setModuleParameterValue,  params: { moduleId: 6456549897,parameterId: 9846546, value:  value} })

end
support=box({top: 300, left: 55, width: 300, height: 40, smooth: 9, color:{red: 0.3, green: 0.3, blue: 0.3}, id: :support })
support.shadow({
                 id: :s3,
                 left: 3, top: 3, blur: 9,
                 invert: true,
                 red: 0, green: 0, blue: 0, alpha: 0.7
               })
support.import(true) do  |content|
  puts "add code here, content:  #{content}"
end
module Vie
  def receptor(msgs)

    puts "message received: #{msgs}"
    # puts "nb of msg found : #{msgs.length}"
    # msgs.each do |msg|
    #   id=msg[:id]
    #   name=msg[:name]
    #   type=msg[:type]
    #   location=msg[:location]
    #   inputs=msg[:inputs]
    #   outputs=msg[:outputs]
    #   # send(type, {id: :id, name: name,location: :location })
    # #   puts '-----------------'
    #   msg.each do |prop,value|
    #     puts "prop: #{prop}, value: #{value}"
    #   end
    # end

  end
end

module Molecules
  def input_box(params = {}, &bloc)
    height_wanted = 15
    width_wanted = 222
    input_back = Atome.new(
      { renderers: [:html], id: :input_back, type: :shape, attach: :view, apply: [:shape_color],
        left: 120, top: 120,data: '', width: width_wanted, height: height_wanted + height_wanted * 20 / 100, smooth: 6 })

    # @atomes[:input_back] = input_back

    Atome.new(
      { renderers: [:html], id: :input_text_color, type: :color, tag: ({ system: true, persistent: true }),
        red: 0.1, green: 0.1, blue: 0.1, alpha: 1 }
    )

    text_input = Atome.new(
      { renderers: [:html], id: :input_text, type: :text, apply: [:input_text_color], component: { size: height_wanted },
        data: :input, left: height_wanted * 20 / 100, top: 0, edit: true, attach: :input_back, height: height_wanted, position: :absolute })

    text_input.touch(true) do
      text_input.component({ selected: { color: 'rgba(0,0,0,0.3)', text: :orange } })
    end

    text_input.keyboard(:down) do |native_event|
      event = Native(native_event)
      if event[:keyCode].to_s == '13'
        # we prevent the input
        event.preventDefault()
      end

    end

    text_input.keyboard(:up) do |native_event|
      input_back.data=text_input.data
    end
    # @atomes[:input_text] = text_input

    input_back
  end
end

class Atome
  include Vie
  include Molecules


end

A.input_box



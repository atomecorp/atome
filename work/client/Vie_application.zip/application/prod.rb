# frozen_string_literal: true
require './get_modules_test'
receptor=text({ data: "message received ", top: 120,left: 33, id: :receptor, edit: true, position: :absolute })
get_modules=text({ data: "get modules", top: 33, id: :modules_list })
get_projects=text({ data: "get projects", top: 33, id: :projects_list })
load_project=text({ data: "load project", top: 33, id: :current_project })
add_relation=text({ data: "add relation", top: 33, id: :relation })

get_modules.touch(true) do
  A.controller({ action: :get_modules }) do |msg|
    receptor.data(msg)
  end
end
get_projects.touch(true) do
  A.controller({ action: :get_projects }) do |msg|
    receptor.data(msg)
  end
end

load_project.touch(true) do
  A.controller({ action: :load_project , id: 123345242 }) do |msg|
    receptor.data(msg)
  end
end

add_relation.touch(true) do
  A.controller({ action: :add_relation, source: {id: 76576, slot: 2}, target: {id: 7665, slot: 2} }) do |msg|
    receptor.data(msg)
  end
end







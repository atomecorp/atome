# frozen_string_literal: true


c = circle({ height: 400, width: 200, top: 100, left: 0, top: 100 })

puts "infos : #{c.infos}"
puts "width : #{c.infos[:width]}"




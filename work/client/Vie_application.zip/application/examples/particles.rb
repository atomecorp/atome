# frozen_string_literal: true

b = box({ left: 777 })
puts "b ahas the following paticles : #{b.particles}"
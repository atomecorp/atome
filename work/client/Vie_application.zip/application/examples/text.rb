# frozen_string_literal

t2 = text({ data: ['this is ', :super, { data: 'cool', color: :red, id: :new_one }], component: { size: 33 }, left: 120 })
the_text = text({  data: 'hello for al the people in front of their machine', center: true, top: 120, width: 77, component: { size: 11 } })


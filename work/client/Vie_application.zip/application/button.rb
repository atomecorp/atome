# frozen_string_literal: true






shadow({
         left: 3, top: 3, blur: 3,
         id: :active_shadow,
         invert: true,
         red: 0, green: 0, blue: 0, alpha: 1
       })

shadow({
         left: 3, top: 3, blur: 3,
         id: :inactive_shadow,
         red: 0, green: 0, blue: 0, alpha: 1
       })

text({data: :cmd_here, id: :texto, top: 20, position: :absolute, edit: true})
but= grab(:intuition).button({id: :toto, states: 3, left: 250, top: 0}) do |state|
  # puts state
  case state

  when 0
    # alert "#{state} = 0"

    # but.color(:white)
    but.remove(:inactive_shadow)
    but.apply(:active_shadow)
    but.color(:white)
  when 1
    A.controller({ action: :get_modules }) do |msg|
      grab(:texto).data(msg)
    end

    # alert "#{state} = 1"
    but.color(:white)
    but.remove(:active_shadow)
    but.apply(:inactive_shadow)
    but.color(:red)
  when 2
    but.color(:gray)
    but.remove(:active_shadow)
    but.apply(:inactive_shadow)
  end
end
# b=box({color: :red, left: 99, top: 99})



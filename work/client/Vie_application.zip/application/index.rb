# # frozen_string_literal: true
JS.eval('localStorage.clear()')

Universe.allow_localstorage = true

# def receptor(msgs)
#   puts "New message received: #{msgs}"
#
#   parsed = JSON.parse(msgs)
#
#   # puts
#   puts parsed
#   puts '---'
# end
# require './version'
# require './styles'
# require './matrixs.rb'
# require './sliders'
# require './inputs'
# require './button'
# require './toolbar'
# require './list'
# console(true)
# require './verif'
require './tool_box'
# require './prod'

# logo
# logo =image({ path: "medias/images/icons/vie.svg", width: 33, left:15 })
#
# logo.touch(true) do
#   logo.animate({ to: 999})
# end

# b = box({top: 99})
# b.touch(true) do
#   b.alternate(
#                 { width: 33 },   {  width: 99 }
#               )
#   # debut = Time.now
#
#   # Effectuer la première action ici
#   # Exemple: sleep(2) - Cela va simplement faire une pause dans le programme pendant 2 secondes
#
#   A.controller({ action: :get_modules })
#   # Effectuer d'autres actions si nécessaire
#
#   # # Capturer le temps de fin
#   # fin = Time.now
#   #
#   # # Calculer la durée
#   # duree = fin - debut
#   #
#   # # Afficher la durée
#   # puts "Temps écoulé : #{duree} secondes."
# end

# # ########### console
# console(true)

# def toggle_console
#   if @state
#     @state = false
#     console(false)
#   else
#     console(true)
#     @state = true
#   end
#
# end
# support = box({ top: 250, left: 150, width: 300, height: 40, smooth: 9, color: { red: 0.3, green: 0.3, blue: 1 }, id: :support })
#
# support.shadow({
#                  id: :s3,
#                  left: 3, top: 3, blur: 9,
#                  invert: true,
#                  red: 0, green: 0, blue: 0, alpha: 0.7
#                })
#
# box({ id: :the_boxy, color: :cyan, left: 120 })
#
# support.import(true) do |content|
#   puts "add code here, content:  #{content}"
# end
#
# importer do |val|
#   puts "case 21 #{val}"
# end
#
# # importer(:all) do |val|
# #   alert "case 21 #{val}"
# # end
#
# importer('the_boxy') do |val|
#   puts "yes !!! exception found : #{val}"
# end
# # require './tool_box'
# # require './matrix'
#
# # toolbox=box({id: :toolbox, top: 0, bottom: 0, height: :auto, width: '3%', left: 0, color: :red})
# # inspector=box({id: :inspector, top: 0, bottom: 0, height: :auto, width: '3%', right: 0, left: :auto})
# # contextual=box({id: :infos, top: 0,  height:'3%', width: :auto, right: 0, left: 0})
# # details=box({id: :infos, bottom: 0, top: :auto, height:'12%', width: :auto, right: 0, left: 0})
# #
# # light_box=matrix({ width: 69, height:69, color: :red, unit: { width: '%', height: '%' }, center: true })
# #
#
# # clear play paste mix
#
# # class HTML
# #
# #   def table(data)
# #     alert data.first.keys
# #     table_html = JS.global[:document].createElement("table")
# #
# #     # Créer colgroup
# #     colgroup = JS.global[:document].createElement("colgroup")
# #     data.first.keys.each do |key|
# #       col = JS.global[:document].createElement("col")
# #       # Ajouter des styles ou des classes spécifiques à chaque col ici
# #       col.setAttribute('class', key.to_s)
# #       colgroup.appendChild(col)
# #     end
# #     table_html.appendChild(colgroup)
# #
# #     thead = JS.global[:document].createElement("thead")
# #     header_row = JS.global[:document].createElement("tr")
# #     header_row.setAttribute('id', "0")
# #     data.first.keys.each do |header|
# #       th = JS.global[:document].createElement("th")
# #       th.textContent = header
# #       header_row.appendChild(th)
# #     end
# #     thead.appendChild(header_row)
# #     table_html.appendChild(thead)
# #
# #     tbody = JS.global[:document].createElement("tbody")
# #     data.each_with_index do |row, row_index|
# #       tr = JS.global[:document].createElement("tr")
# #       tr.setAttribute('id', row_index.to_s)
# #       row.values.each_with_index do |cell, cell_index|
# #         td = JS.global[:document].createElement("td")
# #         td.setAttribute('id', "#{row_index}_#{cell_index}")
# #         td.style[:border] = "1px solid black"
# #         td.style[:overflow] = "hidden" # Modifié pour cacher le contenu débordant
# #         td.style[:backgroundColor] = "white"
# #         td.style[:boxShadow] = "10px 10px 5px #888888"
# #
# #         # Hauteur fixe pour toutes les cellules
# #         # td.style[:height] = '50px' # Hauteur fixée, par exemple 50px
# #
# #         if cell.instance_of? Atome
# #           html_element = JS.global[:document].getElementById(cell.id.to_s)
# #           td.appendChild(html_element)
# #
# #           # Styles pour contenir l'élément Atome dans la cellule
# #           html_element.style[:height] = '55px'
# #           alert html_element.style[:height]
# #           # html_element.style[:overflow] = 'hidden'
# #           # html_element.style[:objectFit] = 'cover'
# #
# #           # Positionnement de l'élément Atome
# #           html_element.style[:transformOrigin] = "top left"
# #           html_element.style[:position] = "relative"
# #           cell.top(0)
# #           cell.left(0)
# #         else
# #           td.textContent = cell
# #         end
# #
# #         # Largeur des cellules (inchangée)
# #         td.style[:width] = '33px'
# #         tr.appendChild(td)
# #       end
# #       tbody.appendChild(tr)
# #     end
# #     table_html.appendChild(tbody)
# #     JS.global[:document].querySelector("##{@id}").appendChild(table_html)
# #   end
# #
# # end
# #
# # new({ atome: :matrix })
# # new({ particle: :format })
# # new({ particle: :border })
# # new({ particle: :cells }) do |value, user_proc|
# #   user_proc.call
# # end
# # new({ particle: :rows })
# # new({ particle: :columns })
# # new({ method: :border, type: :hash, renderer: :html }) do |value, _user_proc|
# #   thickness = value[:thickness] || 5
# #   type = value[:pattern] || :solid
# #   color = if value[:color]
# #             color_found = value[:color]
# #             "#{color_found.red * 255},#{color_found.green * 255},#{color_found.blue * 255},#{color_found.alpha} "
# #           else
# #             "0,0,0,1"
# #           end
# #
# #   html.style(:border, "#{type} #{thickness}px rgba(#{color})")
# # end
# #
# # new({ method: :data, type: :string, specific: :matrix, renderer: :html }) do |value, _user_proc|
# #   html.table(value)
# # end
# #
# # c = circle({ id: :my_cirle, color: :red, drag: true })
# # c.box
# # c.touch(true) do
# #   alert :okk
# # end
# # m = matrix({ renderers: [:html], attach: :view, id: :my_test_box, type: :matrix, apply: [:shape_color],
# #              left: 333, top: 0, width: 300, smooth: 15, height: 900, overflow: :scroll, data: [
# #     { dfgdf: 1, name: 'Alice', age: 30, no: 'oko', t: 123, r: 654, f: 123, g: 654, w: 123, x: 654, c: 123, v: 654 },
# #     { id: 2, name: 'Bob', age: 22 },
# #     { dfg: 3, name: 'toto', age: 18, no: grab(:my_cirle) },
# #     { dfgd: 3, name: 'tutu', age: 18, no: image(:red_planet) }
# #
# #   ]
# #            })
# # m.color(:orange)
# # m.cells({}) do |params|
# #   alert :cellingd
# # end
# # m.rows({}) do |params|
# #
# # end
# # m.columns({}) do |params|
# #
# # end
# # m.add({column: {fffb: {  name: 'tata', age: 18, no: grab(:my_cirle)}}})
# #
# # m.border({ thickness: 5, color: color(:blue), pattern: :dotted })
# # @state = false
#

#
# console_toggler = circle({ left: 400, color: :black })
# console_toggler.text(:console)
# console_toggler.touch(true) do
#   toggle_console
# end
#
#
# ###############
#
# load_modules = circle({ left: 450 })
# load_modules.text(:modules)
# load_modules.touch(true) do
#   load_modules.controller({ action: :get_modules })
# end
#
#
#
# ###############
# new_project = circle({ left: 500 })
# new_project.text(:new)
# new_project.touch(true) do
#   new_project.controller({ action: :new_project })
# end
#
# ###############
# get_projects = circle({ left: 550 })
# get_projects.text(:get)
# get_projects.touch(true) do
#   get_projects.controller({ action: :get_projects })
# end
#
# ###############
# delete_module = circle({ left: 600 })
# delete_module.text(:delete)
# delete_module.touch(true) do
#   delete_module.controller({ action: :delete_module })
# end
#
#
# ###############
# add_module = circle({ left: 650 })
# add_module.text(:add)
# add_module.touch(true) do
#   add_module.controller({ action: :add_module })
# end
#
#
# ###############
# load_project = circle({ left:700 })
# load_project.text(:load)
# load_project.touch(true) do
#   load_project.controller({ action: :load_project })
# end
#
# ###############
# setModuleParameterValue = circle({ left:800})
# setModuleParameterValue.text(:params)
# setModuleParameterValue.touch(true) do
#   setModuleParameterValue.controller({ action: :setModuleParameterValue,  params: { moduleId: 6456549897,parameterId: 9846546, value:  123} })
# end
#
#

# tb=box({top: 99, left: 99, width: 999})
# t=tb.text({data: :hello, left: 22})
# t=tb.text({data: :hello3, left: 22})
# t=tb.text({data: :hello2, left: 22})
# t=tb.text({data: :hello4, left: 22, position: :absolute})
#

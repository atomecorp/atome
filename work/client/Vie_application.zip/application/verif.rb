# frozen_string_literal: true
require './get_modules_test'
# text({ data: :reception, top: 120, id: :rec })
#
#
#
# b = box({ left: 12, id: :the_first_box, top: 30 })
#
# def act_on(obj)
#   obj.color(:green)
#   obj.left(27)
# end
#
# def act_off(obj)
#   obj.color(:cyan)
#   obj.left(12)
# end
#
# b.touch(true) do
#   b.alternate({  executor: {act_on: b}  }, { executor: {act_off: b}}) do |params|
#     puts "value is"
#   end
#
#   A.controller({ action: :get_modules }) do |msg|
#     grab(:rec).data(msg)
#   end
# end


# alert @get_m.length
# id,name,tags,type,icon,inputs,outputs
modules_list=[]
 @get_m.each do |datas|
   id_found=datas[:id]
   name_found=datas[:name]
   tags_found=datas[:tags]
   type_found=datas[:type]
   icon_found=datas[:icon]
   inputs_found=datas[:inputs]
   outputs_found=datas[:outputs]

   modules_list << {data: name_found}

   # b= box({id: id_found})
   # b.text({data: name_found})

   # puts "--- #{datas.length} ---"
   # puts   "id_found String : #{id_found=datas[:id]} "
   # puts "name_found String : #{name_found=datas[:name]} "
   # puts "tags_found Array : #{tags_found=datas[:tags]} "
   # puts "type_found String : #{type_found=datas[:type]} "
   # puts "icon_found String : #{icon_found=datas[:icon]} "
   # puts "inputs_found Array : #{inputs_found=datas[:inputs]} "
   # puts  "outputs_found Array : #{outputs_found=datas[:outputs]} "
   # puts '******------********'
 end

styles = {
  width: 99,
  height: 15,
  margin: 6,
  shadow: { blur: 9, left: 3, top: 3, id: :cell_shadow, red: 0, green: 0, blue: 0, alpha: 0.6 },
  color: :yellowgreen,
  drag: true,

}
element = { width: 25,
            height: 25,
            component: {size: 12},
            smooth: '100%',
            center: { x: 0, y: 0, dynamic: true },
            left: 10,
            position: :absolute,
            top: 0,
            color: :black,
            type: :text }

grab(:view).list({
                   top: 18,
                   left: 18,
                  styles: styles,
                  element: element,
                  listing: modules_list
                })
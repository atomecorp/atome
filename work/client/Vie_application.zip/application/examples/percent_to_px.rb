# frozen_string_literal: true

bb=box({width: '90%'})
puts bb.to_px(:width)
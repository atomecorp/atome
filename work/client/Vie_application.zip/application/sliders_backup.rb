# frozen_string_literal: true

class Atome

  def set_value(params)
    # @default_value =22
    cursor = grab("#{id}_cursor")
    # alert "#{id}_cursor"
    cursor_height = cursor.height
    cursor_width = cursor.width
    slider_height = height
    slider_width = width


    if @orientation == :vertical
      if  @bipolar = true
        slider_height = slider_height
        cursor_height =  cursor_height
        center_val = slider_height / 2.0
        distance_from_center = (params * (center_val - cursor_height / 2.0)) / -50.0
        cursor_top = center_val + distance_from_center - cursor_height / 2.0
        cursor.top(cursor_top)
      else
        slider_height = slider_height
        cursor_height =  cursor_height
        max_top = slider_height - cursor_height
        cursor_top = max_top - (params * max_top) / 100.0
        cursor.top(cursor_top)
      end

    else
      if  @bipolar = true
        slider_width = slider_width
        cursor_width = cursor_width
        center_val = slider_width / 2.0
        max_left = slider_width - cursor_width
        distance_from_center = (params * (center_val - cursor_width / 2.0)) / -50.0
        cursor_left = center_val + distance_from_center - cursor_width / 2.0
        cursor.left(cursor_left)
      else
        slider_width = slider_width
        cursor_width = cursor_width
        max_left = slider_width - cursor_width
        cursor_left = (params * max_left) / 100.0
        cursor.left(cursor_left)
      end
    end
  end

  def slider(params, &bloc)
    params[:data] = params[:data] ||= 0
    # params[:data]={value: params[:data], default: params[:data]}
    @default_value = params[:data] ||= 0
    bipolar = params.delete(:bipolar)
    bipolar ||= false
    orientation = params.delete(:orientation)
    orientation ||= :horizontal
    attach_to = params[:attach] || :view
    color_found = params[:color] ||= :gray
    default_slider_particles = { color: color_found, width: 333, height: 33, left: 0, top: 0, smooth: 9 }
    default_cursor_particles = { color: color_found, width: 29, height: 29, left: 0, smooth: '100%' }
    cursor_found = params.delete(:cursor)
    slider_particle = default_slider_particles.merge(params)
    slider = grab(attach_to).box(slider_particle)
    cursor_particle = default_cursor_particles.merge(cursor_found).merge({ id: "#{slider.id}_cursor" })

    slider.shadow({
                    id: :s2,
                    left: 3, top: 3, blur: 9,
                    invert: true,
                    red: 0, green: 0, blue: 0, alpha: 0.7
                  })
    cursor = slider.box(cursor_particle)
    if orientation == :vertical
      if bipolar
        # vertical bi-polar
        @orientation = :vertical
        @bipolar = true
        cursor_left = (slider_particle[:width] - cursor_particle[:width]) / 2.0
        cursor_top = (slider_particle[:height] - cursor_particle[:height]) / 2.0
        cursor.top(cursor_top)
        cursor.left(cursor_left)
        bloc.call(cursor_particle[:bottom])
        slider.data(cursor_particle[:bottom])
        center_val = slider.height / 2.0
        cursor.drag({ restrict: { max: { top: slider.height - cursor_particle[:height], left: cursor_left } } }) do |_event|
          distance_from_center = cursor.top.to_f + cursor_particle[:height] / 2.0 - center_val
          value = -50 * (distance_from_center / (center_val - cursor_particle[:height] / 2.0))
          bloc.call(value)
          slider.data(value)
        end
        ##########----#########
        slider_height = slider_particle[:height]
        cursor_height = cursor_particle[:height]
        center_val = slider_height / 2.0
        distance_from_center = (@default_value * (center_val - cursor_height / 2.0)) / -50.0
        cursor_top = center_val + distance_from_center - cursor_height / 2.0
        cursor.top(cursor_top)
        ##########----#########
      else
        # vertical linear
        @orientation = :vertical
        @bipolar = false
        cursor_left = (slider_particle[:width] - cursor_particle[:width]) / 2.0
        cursor.left(cursor_left)
        bloc.call(cursor_particle[:bottom])
        slider.data(cursor_particle[:bottom])
        min_val = slider_particle[:height] - cursor_particle[:height]
        cursor.bottom(cursor_left)
        cursor.drag({ restrict: { max: { top: min_val, left: cursor_left } } }) do |_event|
          value = 100 - (cursor.top.to_f / (slider_particle[:height] - cursor_particle[:height]) * 100)
          bloc.call(value)
          slider.data(value)
        end
        ##########----#########
        slider_height = slider_particle[:height]
        cursor_height = cursor_particle[:height]
        max_top = slider_height - cursor_height
        cursor_top = max_top - (@default_value * max_top) / 100.0
        cursor.top(cursor_top)
        ##########----#########
      end
    else
      if bipolar
        @orientation = :horizontal
        @bipolar = true
        # Horizontal bi-polar
        cursor_top = (slider_particle[:height] - cursor_particle[:height]) / 2.0
        cursor_left = (slider_particle[:width] - cursor_particle[:width]) / 2.0
        cursor.left(cursor_left)
        bloc.call(cursor_particle[:left])
        slider.data(cursor_particle[:left])
        cursor.top(cursor_top)
        cursor.drag({ restrict: { max: { left: slider_particle[:width] - cursor_particle[:width], top: cursor_top }, min: { top: cursor_top } } }) do |_event|
          center_val = slider_particle[:width] / 2.0
          distance_from_center = cursor.left.to_f + cursor_particle[:width] / 2.0 - center_val
          value = -50 * (distance_from_center / (center_val - cursor_particle[:width] / 2.0))
          bloc.call(value)
          slider.data(value)
        end
        ##########----#########
        slider_width = slider_particle[:width]
        cursor_width = cursor_particle[:width]
        center_val = slider_width / 2.0
        max_left = slider_width - cursor_width
        distance_from_center = (@default_value * (center_val - cursor_width / 2.0)) / -50.0
        cursor_left = center_val + distance_from_center - cursor_width / 2.0
        cursor.left(cursor_left)
        ##########----#########
      else
        # Horizontal linear
        @orientation = :horizontal
        @bipolar = false
        cursor_top = (slider_particle[:height] - cursor_particle[:height]) / 2.0
        bloc.call(cursor_particle[:left])
        slider.data(cursor_particle[:left])
        cursor.top(cursor_top)
        cursor.drag({ restrict: { max: { left: slider_particle[:width] - cursor_particle[:width], top: cursor_top }, min: { top: cursor_top } } }) do |_event|
          value = cursor.left.to_f / (slider_particle[:width] - cursor_particle[:width]) * 100
          bloc.call(value)
          slider.data(value)
        end
        ##########----#########
        slider_width = slider_particle[:width]
        cursor_width = cursor_particle[:width]
        max_left = slider_width - cursor_width
        cursor_left = (@default_value * max_left) / 100.0
        cursor.left(cursor_left)
        ##########----#########
      end

    end
    cursor.shadow({
                    id: :s4,
                    left: 1, top: 1, blur: 3,
                    option: :natural,
                    red: 0, green: 0, blue: 0, alpha: 0.6
                  })

    slider
  end

  def dial(params)
    def_1 = "M 0,512 L 1024,512 1024,562 0,562 Z"

    horizontal = vector({ top: 33, data: { path: { d: def_1, id: :p1, stroke: :black, 'stroke-width' => 0, fill: :green } } })

    def_2 = "M 536.75,-0.25 C 536.75,-0.25 536.75,-0.08 536.75,0.25 536.75,25.82 536.75,1023.75 536.75,1023.75 536.75,1024.08 536.75,1024.25 536.75,1024.25 L 486.75,1024.25 C 486.75,1024.25 486.75,1024.08 486.75,1023.75 486.75,998.18 486.75,0.25 486.75,0.25 486.75,0.24 486.75,-0.2 486.75,-0.2 L 536.75,-0.25 536.75,-0.25 Z M 536.75,-0.25"

    vertical = vector({ top: 33, left: 99, data: { path: { d: def_2, id: :p2, stroke: :black, 'stroke-width' => 0, fill: :green } } })

  end
end

label = text({ data: 0, top: 400, left: 69, component: { size: 12 }, color: :gray })

grab(:intuition).slider({ id: :toto, width: 333, data: 33, height: 25, attach: :intuition, left: 99, top: 350, color: :red, cursor: { color: :red, width: 33, height: 33, smooth: 3 } }) do |value|
  label.data("(#{value})")
end

aa = grab(:intuition).slider({ orientation: :vertical, data: 50, bipolar: true, width: 25, height: 333, attach: :intuition, left: 555, top: 33, color: :red, cursor: { color: :red, width: 33, height: 33, smooth: 3 } }) do |value|
  label.data("(#{value})")
end
# aa.value(50)

b = box({ top: :auto, bottom: 0, left: :auto, right: 0 })

b.touch(true) do
  puts "==> #{aa.data}"
end



class HTML

  def fill(params)

    # we remove previous background
    elements_to_remove = @element.getElementsByClassName('background')

    elements_to_remove = elements_to_remove.to_a
    elements_to_remove.each do |child|
      @element.removeChild(child)
    end
    params.each do |param|
      left_pos = param[:left] ||= 0
      top_pos = param[:top] ||= 0
      background_layer = JS.global[:document].createElement("div")
      background_layer[:style][:transform] = "rotate(#{param[:rotate]}deg)" # Applique une rotation de 45 degrés à l'élément
      background_layer[:style][:position] = "absolute"

      if param[:position]
        background_layer[:style][:top] = "#{param[:position][:x]}px"
        background_layer[:style][:left] = "#{param[:position][:y]}px"
      else
        background_layer[:style][:top] = "0"
        background_layer[:style][:left] = "0"
      end

      if param[:size]
        background_layer[:style][:width] = "#{param[:size][:x]}px"
        background_layer[:style][:height] = "#{param[:size][:y]}px"
      else
        background_layer[:style][:width] = "100%"
        background_layer[:style][:height] = "100%"
      end

      atome_path = grab(param[:atome]).path
      background_layer[:style][:backgroundPosition] = "#{left_pos}px #{top_pos}px"
      background_layer[:style][:backgroundImage] = "url('#{atome_path}')"
      background_layer[:style][:backgroundRepeat] = 'repeat'
      background_layer[:className] = 'background'
      background_layer[:style][:opacity] = param[:opacity]
      if param[:repeat]
        img_width = @original_atome.width / param[:repeat][:x]
        img_height = @original_atome.height / param[:repeat][:y]
        background_layer[:style][:backgroundSize] = "#{img_width}px #{img_height}px"
      else
        background_layer[:style][:backgroundSize] = "#{param[:width]}px #{param[:height]}px"
      end
      @element.appendChild(background_layer)
    end
  end

end

box({ width: 300, height: 333, color: { alpha: 0 } })
image({ id: :logo, path: 'medias/images/logos/atome.svg', width: 66, left: 555 })
def_2 = "M 536.75,-0.25 C 536.75,-0.25 536.75,-0.08 536.75,0.25 536.75,25.82 536.75,1023.75 536.75,1023.75 536.75,1024.08 536.75,1024.25 536.75,1024.25 L 486.75,1024.25 C 486.75,1024.25 486.75,1024.08 486.75,1023.75 486.75,998.18 486.75,0.25 486.75,0.25 486.75,0.24 486.75,-0.2 486.75,-0.2 L 536.75,-0.25 536.75,-0.25 Z M 536.75,-0.25"

vector({ id: :my_svg, top: 33, left: 99, data: { path: { d: def_2, id: :p2, stroke: :black, 'stroke-width' => 0, fill: :green } } })

class Atome

  def b64Totag(params)

    unless params[:target]
      new_img = image({ left: 0, top: 0 })
      params[:target] = new_img.id
    end
    new_tag = <<STRR
  var serializer = new XMLSerializer();
  var svg_string = serializer.serializeToString(document.getElementById('#{params[:id]}'));
  var encoded_svg = btoa(unescape(encodeURIComponent(svg_string)));
  var img = document.getElementById('#{params[:target]}');
  img.src = "data:image/svg+xml;base64," + encoded_svg;
  var parent = document.getElementById('#{id}');
  parent.appendChild(img);
STRR

    JS.eval(new_tag)
    new_atome = grab(params[:target])
    html_obj = new_atome.html.object
    obj_src = html_obj[:src]
    new_atome.path(obj_src)
    new_atome
  end

end

grab(:view).b64Totag({ id: 'my_svg' })

b = box({ width: 300, height: 333, color: { alpha: 0 } })
wait 1 do
  grab(:view).b64Totag({ id: 'my_svg', target: :logo })
  wait 1 do
    b.fill([atome: :logo, width: 33, height: 33])
  end
end

b.fill([atome: :logo, width: 33, height: 33])



# frozen_string_literal: true

b= box({ center:  { x: 0, y: 0, dynamic: true }})

# b.center({ x: '10%', y: '20%' })
# b.center({ x: true, y: true })
# box({center: true})
# frozen_string_literal: true

# Universe.categories is used to get the existing category to sort particles , ex:

puts Universe.categories

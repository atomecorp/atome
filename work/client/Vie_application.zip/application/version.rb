# frozen_string_literal: true

puts 'vie version: 0.002'
puts 'v-UIe version: 0.001'

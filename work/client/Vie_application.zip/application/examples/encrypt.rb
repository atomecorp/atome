# frozen_string_literal: true


encoded=A.encrypt('hello')

text("encrypted string : #{encoded}")